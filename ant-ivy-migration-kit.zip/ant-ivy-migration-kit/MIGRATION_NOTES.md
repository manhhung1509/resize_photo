# Migration Notes

## Problem

The existing project stores many JARs under `/ServerLib/lib/terasoluna5` and references them from Eclipse `all.userlibraries`.
This makes TERASOLUNA upgrades manual and risky because every library version needs to be updated by hand.

## Proposed solution

Keep Ant as the build tool, but use Apache Ivy to resolve dependencies.

Ant remains responsible for:

- clean
- compile
- test
- war/build packaging

Ivy becomes responsible for:

- resolving dependencies
- downloading JARs
- retrieving JARs into `/ServerLib/lib/terasoluna5`
- syncing removed old JARs
- supporting reproducible dependency refresh

## Files to copy into real project

Copy these files/folders:

```text
build.xml
build.properties
ivy.xml
ivysettings.xml
scripts/
.gitignore
```

If your project already has `build.xml`, merge the Ivy targets instead of replacing the whole file.

## Targets to merge into existing Ant build

- `resolve-runtime`
- `resolve-runtime-sources`
- `resolve-test`
- `generate-eclipse-userlibraries`
- `verify-libs`
- `full-refresh`

## Common issues

### Ivy taskdef error

Make sure `tools/ivy-*.jar` exists or Ivy is installed under Ant lib.

### Oracle JDBC not found

Add Oracle JDBC artifacts into company Nexus/Artifactory or keep them in `ServerLib/lib/extension` manually.

### Duplicate JAR versions

Run:

```bash
ant verify-libs
```

### Runtime works but test fails

Check old test libraries. In the old config, test libraries may use old versions such as old Spring Test or old SLF4J.
Align test dependencies with runtime dependencies.
