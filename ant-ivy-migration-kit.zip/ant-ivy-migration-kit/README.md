# Ant + Ivy Migration Kit for Legacy TERASOLUNA Project

This kit keeps the project on **Ant** but adds **Apache Ivy** for dependency resolution.
It is intended for projects that are not allowed to migrate to Maven or Gradle.

## Files

```text
build.xml
build.properties
ivy.xml
ivysettings.xml
scripts/generate_eclipse_userlibraries.py
scripts/verify_libs.sh
ServerLib/lib/terasoluna5/
ServerLib/lib/test/
ServerLib/lib/extension/
```

## Setup

1. Download Apache Ivy jar, for example `ivy-2.5.3.jar`.
2. Put it here:

```text
tools/ivy-2.5.3.jar
```

Or install Ivy into Ant's global lib folder.

## Current version

Edit `build.properties`:

```properties
terasoluna.version=5.7.0.RELEASE
```

For upgrade:

```properties
terasoluna.version=5.8.0.RELEASE
```

## Commands

Resolve runtime JARs:

```bash
ant resolve-runtime
```

Resolve runtime source JARs:

```bash
ant resolve-runtime-sources
```

Resolve test JARs:

```bash
ant resolve-test
```

Generate Eclipse `all.userlibraries`:

```bash
ant generate-eclipse-userlibraries
```

Full refresh:

```bash
ant full-refresh
```

Compile:

```bash
ant compile
```

## Important notes

- Do not manually edit `all.userlibraries` anymore if you use the generator.
- Do not commit generated JAR files into Git unless your company policy requires it.
- Keep `ivy.xml`, `ivysettings.xml`, `build.xml`, and `build.properties` as the source of truth.
- Oracle JDBC dependencies may require a company Nexus/Artifactory repository because of license restrictions.
- If your CI cannot access the internet, configure `ivysettings.xml` to use your internal Nexus/Artifactory repository.

## Recommended migration flow

1. Start with current TERASOLUNA version, for example `5.7.0.RELEASE`.
2. Run `ant full-refresh`.
3. Compare generated JAR list with old `/ServerLib/lib/terasoluna5`.
4. Fix missing direct dependencies in `ivy.xml`.
5. Compile and test.
6. Change `terasoluna.version` to the target version, for example `5.8.0.RELEASE`.
7. Run `ant full-refresh` again.
8. Compile and test again.
