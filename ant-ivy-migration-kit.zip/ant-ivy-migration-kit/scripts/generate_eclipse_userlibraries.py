#!/usr/bin/env python3
"""
Generate Eclipse all.userlibraries from generated lib folders.

Usage:
  python3 scripts/generate_eclipse_userlibraries.py \
      --terasoluna-lib-dir ServerLib/lib/terasoluna5 \
      --test-lib-dir ServerLib/lib/test \
      --extension-lib-dir ServerLib/lib/extension \
      --output all.userlibraries
"""

import argparse
from pathlib import Path
import xml.etree.ElementTree as ET
from xml.dom import minidom


def add_library(root: ET.Element, name: str, lib_dir: Path) -> None:
    library = ET.SubElement(root, "library", {
        "name": name,
        "systemlibrary": "false",
    })

    if not lib_dir.exists():
        return

    jars = sorted(p for p in lib_dir.glob("*.jar") if not p.name.endswith("-sources.jar"))

    for jar in jars:
        attrs = {"path": str(jar).replace("\\", "/")}

        source_name = jar.name[:-4] + "-sources.jar"
        source_path = jar.with_name(source_name)
        if source_path.exists():
            attrs["source"] = str(source_path).replace("\\", "/")

        ET.SubElement(library, "archive", attrs)


def prettify_xml(root: ET.Element) -> str:
    rough = ET.tostring(root, encoding="utf-8")
    parsed = minidom.parseString(rough)
    return parsed.toprettyxml(indent="    ", encoding="UTF-8").decode("utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--terasoluna-lib-dir", required=True)
    parser.add_argument("--test-lib-dir", required=True)
    parser.add_argument("--extension-lib-dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    root = ET.Element("eclipse-userlibraries", {"version": "2"})

    add_library(root, "TERASOLUNA５ライブラリ", Path(args.terasoluna_lib_dir))
    add_library(root, "テストライブラリ", Path(args.test_lib_dir))
    add_library(root, "拡張ライブラリ", Path(args.extension_lib_dir))

    output = Path(args.output)
    output.write_text(prettify_xml(root), encoding="utf-8")
    print(f"Generated {output}")


if __name__ == "__main__":
    main()
