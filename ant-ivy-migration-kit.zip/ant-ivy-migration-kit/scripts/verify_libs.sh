#!/usr/bin/env bash
set -euo pipefail

LIB_DIR="${1:-ServerLib/lib/terasoluna5}"

if [ ! -d "$LIB_DIR" ]; then
  echo "ERROR: lib directory does not exist: $LIB_DIR" >&2
  exit 1
fi

echo "Checking duplicate artifacts in: $LIB_DIR"

python3 - "$LIB_DIR" <<'PY'
import re
import sys
from pathlib import Path
from collections import defaultdict

lib_dir = Path(sys.argv[1])

# Simple artifact parser: artifact-version.jar
# It is intentionally conservative and mainly used to catch obvious duplicates.
version_pattern = re.compile(r"^(?P<artifact>.+)-(?P<version>[0-9][A-Za-z0-9_.\-]*)\.jar$")
artifacts = defaultdict(list)

for jar in sorted(lib_dir.glob("*.jar")):
    if jar.name.endswith("-sources.jar"):
        continue
    m = version_pattern.match(jar.name)
    if not m:
        continue
    artifacts[m.group("artifact")].append(jar.name)

has_duplicate = False
for artifact, jars in sorted(artifacts.items()):
    if len(jars) > 1:
        has_duplicate = True
        print(f"WARNING: possible duplicate versions for {artifact}:")
        for jar in jars:
            print(f"  - {jar}")

if not has_duplicate:
    print("OK: no obvious duplicate artifact versions found.")
PY
